import time

def generate_id():
    return str(time.time_ns())

# bcrypt