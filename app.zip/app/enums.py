from enum import Enum

class Language(Enum):
    English = 'en'
    French = 'fr'
    Russian = 'ru'
